# MEAAF — Replit Build Package

هذا الملف مخصص للرفع إلى Replit مع ملف التعليمات:
MEAAF-MASTER-PRODUCTION-PROMPT.md

## طريقة الاستخدام

1. ارفع هذا الملف/الحزمة إلى مشروع Replit جديد.
2. ارفع الشعار الرسمي أيضًا إذا لم يكن ضمن المشروع.
3. افتح Agent.
4. اجعل ملف MEAAF-MASTER-PRODUCTION-PROMPT.md هو تعليمات التنفيذ الرئيسية.
5. اطلب من Agent تنفيذ المشروع Gate-by-Gate.
6. لا تسمح بإعلان أي وظيفة PASS إلا مع اختبار ودليل.
7. بعد كل Gate اطلب Build + Test + Fix + Retest.
8. إذا كانت بيئة Replit لا تستطيع تنفيذ اختبار Windows فعليًا، يجب تسجيله BLOCKED وعدم اختراع PASS.
